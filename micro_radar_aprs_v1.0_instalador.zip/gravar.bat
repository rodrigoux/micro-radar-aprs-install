@echo off
setlocal
cd /d "%~dp0"
title Micro Radar APRS - Gravador de firmware

echo.
echo  ==========================================
echo   MICRO RADAR APRS v1.0
echo   Gravacao do firmware na placa ESP32 CYD
echo  ==========================================
echo.
echo  Antes de continuar:
echo    1. Conecte a placa no USB com um cabo de DADOS
echo    2. Feche o monitor serial, se houver algum aberto
echo.
pause

echo.
echo  Portas seriais encontradas neste computador:
echo.
powershell -NoProfile -Command "$p = Get-CimInstance Win32_PnPEntity | Where-Object { $_.Name -match '\(COM\d+\)' }; if ($p) { $p | ForEach-Object { '    ' + $_.Name } } else { Write-Host '    (nenhuma encontrada - falta o driver CH340 ou CP210x)' }"
echo.
echo  A sua placa aparece como CH340, CP210x ou USB-SERIAL.
echo.

set "PORTA="
set /p PORTA=Digite a porta da placa (ex: COM5) ou ENTER para procurar sozinho:

set "ARG_PORTA="
if defined PORTA set "ARG_PORTA=--port %PORTA%"

echo.
if defined PORTA (
    echo  Gravando na %PORTA%...
) else (
    echo  Nenhuma porta informada - varrendo todas as seriais...
)
echo.

esptool.exe --chip esp32 %ARG_PORTA% --baud 921600 write_flash 0x1000 bootloader.bin 0x8000 partitions.bin 0xe000 boot_app0.bin 0x10000 firmware.bin
if errorlevel 1 goto tentar_lento
goto sucesso

:tentar_lento
echo.
echo  A gravacao rapida falhou. Tentando de novo em velocidade menor...
echo.
esptool.exe --chip esp32 %ARG_PORTA% --baud 115200 write_flash 0x1000 bootloader.bin 0x8000 partitions.bin 0xe000 boot_app0.bin 0x10000 firmware.bin
if errorlevel 1 goto falhou

:sucesso
echo.
echo  ==========================================
echo   PRONTO. A placa vai reiniciar sozinha.
echo  ==========================================
echo.
echo  Agora conecte-se a rede WiFi "MicroRadar-Setup"
echo  para configurar a sua rede. Veja o LEIAME.txt.
echo.
pause
exit /b 0

:falhou
echo.
echo  ==========================================
echo   FALHOU
echo  ==========================================
echo.
echo  Causas mais comuns:
echo    - Porta errada (rode de novo e escolha outra da lista)
echo    - Cabo USB so de energia (troque por um cabo de dados)
echo    - Falta o driver USB-serial: instale o CH340 ou o CP210x
echo    - A porta esta ocupada por outro programa (feche o monitor serial)
echo.
echo  Veja o LEIAME.txt para mais detalhes.
echo.
pause
exit /b 1
